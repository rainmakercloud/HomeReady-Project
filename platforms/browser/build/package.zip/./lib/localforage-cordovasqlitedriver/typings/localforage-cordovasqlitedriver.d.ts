/// <reference types="localforage" />

declare module "localforage-cordovasqlitedriver" {
    var cordovaSQLiteDriver: LocalForageDriver;
    export = cordovaSQLiteDriver;
}
