/* UAT ORG */
homeReady.constant('homereadyConfig', {
  productionURL: "https://login.salesforce.com",
  testURL: "https://test.salesforce.com",
  productionCommunityURL: "",
  testCommunityURL: "https://dev-gbcrm-homeworx.cs52.force.com/portal",
  synchronizationIdleTimeout: 1,
  synchronizationIdleCountdown: 1,
  syncDelay: 0,
  clientId: "3MVG9jfQT7vUue.FqdG4DxZu.vhLGuEJlX.aSxICXto6nhkP0mIIR0O9DsfvzJR8KwiiOK2DVX3cTUZNCSFhO",
  clientSecret: "842700102299482368"
})
//*/
/* RMA ORG
homeReady.constant('homereadyConfig', {
  productionURL: "https://login.salesforce.com",
  testURL: "https://test.salesforce.com",
  productionCommunityURL: "",
  testCommunityURL: "https://rma-gbcrm-homeworx.cs52.force.com/portal",
  synchronizationIdleTimeout: 5,
  synchronizationIdleCountdown: 5,
  syncDelay: 10000,
  clientId: "3MVG9jfQT7vUue.HdWtN8rkkgEbuu6FFqbmY2nBt8hnVhnEtN96.CDBjtm6ICzaJNXszfOFN2egaAjvdW3hLC",
  clientSecret: "9111208548173251556"
})
*/
